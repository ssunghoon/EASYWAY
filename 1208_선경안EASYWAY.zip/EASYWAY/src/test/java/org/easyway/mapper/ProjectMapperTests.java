package org.easyway.mapper;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProjectMapperTests {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
