package org.easyway.mapper;

public class NoticeMapperTests {

}
