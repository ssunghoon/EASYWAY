package org.easyway.service;

public class ScheduleServiceTests {

}
