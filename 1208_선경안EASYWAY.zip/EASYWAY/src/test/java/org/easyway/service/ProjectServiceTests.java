package org.easyway.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProjectServiceTests {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
